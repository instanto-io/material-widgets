package gwt.material.design.jscore.client.api.media;

/*
 * Copyright 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsProperty;
import jsinterop.annotations.JsType;

@JsType(isNative = true)
public class MediaStreamTrack {

    @JsProperty
    public boolean enabled;

    @JsProperty
    public String id;

    @JsProperty
    public String kind;

    @JsProperty
    public String label;

    @JsProperty
    public boolean muted;

    @JsProperty
    public boolean readOnly;

    @JsProperty
    public boolean remote;

    @JsMethod
    public native void stop();
}
