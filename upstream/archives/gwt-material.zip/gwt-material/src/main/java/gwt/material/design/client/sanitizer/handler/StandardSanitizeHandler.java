/*
 * #%L
 * GwtMaterial
 * %%
 * Copyright (C) 2015 - 2022 GwtMaterialDesign
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
package gwt.material.design.client.sanitizer.handler;

import com.google.gwt.regexp.shared.MatchResult;
import com.google.gwt.regexp.shared.RegExp;
import gwt.material.design.client.sanitizer.Patterns;
import gwt.material.design.client.sanitizer.ValueSanitizerException;

public class StandardSanitizeHandler extends AbstractSanitizeHandler {

    public StandardSanitizeHandler() {
    }

    @Override
    public boolean sanitize(String value) {
        RegExp regExp = RegExp.compile(Patterns.STANDARD);
        MatchResult matcher = regExp.exec(value);
        if (value != null && !value.isEmpty() && matcher == null) {
            throw new ValueSanitizerException("Only Standard characters are allowed");
        }
        return true;
    }
}
